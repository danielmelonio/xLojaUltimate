﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using xLojaUltimate.ModeloBanco;

namespace xLojaUltimate
{
    public class Gerenciador<T> : IDisposable where T : class
    {
        private ModeloBanco.LojaDados DB = new LojaDados();
        //Só pra testarkljsdfjklsdklj
        public List<T> Listar()
        {
            return DB.Set<T>().ToList();
        }

        public T Buscar(int id)
        {
            return DB.Set<T>().Find();
        }

        public void Criar(T conta)
        {
            DB.Set<T>().Add(conta);
        }

        public void Excluir(int id)
        {
            var busca = DB.Set<T>().Find(id);
            DB.Set<T>().Remove(busca);
        }
        public void Alterar(T model)
        {
            DB.Entry<T>(model).State = System.Data.Entity.EntityState.Modified;
        }
        public void Salvar()
        {
            DB.SaveChanges();
        }
        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
