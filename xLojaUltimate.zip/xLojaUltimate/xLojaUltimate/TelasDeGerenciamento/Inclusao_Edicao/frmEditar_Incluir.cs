﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using xLojaUltimate.ModeloBanco;

namespace xLojaUltimate.TelasDeGerenciamento.Inclusao_Edicao
{
    public partial class frmEditar_Incluir : Form
    {
        //
        Gerenciador<Funcionario> CRUD = new Gerenciador<Funcionario>();
        public int id { get; set; }        
        public frmEditar_Incluir()
        {
            InitializeComponent();            
        }
        public frmEditar_Incluir(string edite, int id)
        {
            if(edite == "edit")
            {
                try
                {
                    //lblControle.Text = "Editar Funcionário";
                    var busca = CRUD.Buscar(id);
                    txtNome.Text = busca.FUNNOME;
                }
                catch (NullReferenceException ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void frmEditar_Incluir_Load(object sender, EventArgs e)
        {

        }
    }
}
