﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using xLojaUltimate.ModeloBanco;

namespace xLojaUltimate.TelasDeGerenciamento
{
    public partial class frmFuncionarios : Form
    {
        Gerenciador<Funcionario> CRUD = new Gerenciador<Funcionario>();
        public frmFuncionarios()
        {
            InitializeComponent();
            gdvEmployees.DataSource = CRUD.Listar();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var open = new xLojaUltimate.TelasDeGerenciamento.Inclusao_Edicao.frmEditar_Incluir();
            open.ShowDialog();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(gdvEmployees.CurrentRow.Cells[0].Value);
            var open = new xLojaUltimate.TelasDeGerenciamento.Inclusao_Edicao.frmEditar_Incluir("edit", id);
            open.ShowDialog();
        }
    }
}
