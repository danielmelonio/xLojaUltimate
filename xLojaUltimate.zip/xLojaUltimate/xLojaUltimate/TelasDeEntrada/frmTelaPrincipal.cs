﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace xLojaUltimate
{
    public partial class frmTelaPrincipal : Form
    {
        public frmTelaPrincipal()
        {
            InitializeComponent();
        }
        //CONTEINER DE FORMULÁRIOS: COMEÇA AQUI;
        //
        private void btnFunc_Click(object sender, EventArgs e)
        {
            var open = new xLojaUltimate.TelasDeGerenciamento.frmFuncionarios();
            open.ShowDialog();
        }

        private void btnConfig_Click(object sender, EventArgs e)
        {
            var open = new xLojaUltimate.TelasDePersonalizacao.frmConfigurar();
            open.ShowDialog();
        }

        private void btnVendas_Click(object sender, EventArgs e)
        {
            var open = new xLojaUltimate.TelasDeGerenciamento.frmVendas();
            open.ShowDialog();
        }
        //
        //TERMINA AQUI;
    }
}
