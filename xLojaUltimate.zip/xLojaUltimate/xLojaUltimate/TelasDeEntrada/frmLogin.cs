﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace xLojaUltimate
{
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
            int largura = this.Width / 2;
            int altura = this.Width / 2;            
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var open = new frmTelaPrincipal();
            open.ShowDialog();
            //this.Hide();
        }
    }
}
